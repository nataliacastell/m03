import java.util.Scanner;
/*Hem importat la llibreria Scanner*/
public class cas1cn {
  public static void cs1cn(String[] args)
  {
  // -------> Matricula
  //
  System.out.println(
  " Introdueix la matricula completa "
  );
  Scanner entrada1 = new Scanner (System.in);
  String matricula = entrada1.nextLine();
  // ------> Entrada
  //
  int unahora = 60;
  int unminut = 1;
  System.out.println(
  " Digues a quina hora i minut has arribat al estacionament (Primer la hora, desprès els minuts) "
  );
  Scanner entrada2 = new Scanner (System.in);
  int horaint = entrada2.nextInt();
  Scanner entrada3 = new Scanner (System.in);
  int minutint = entrada3.nextInt();
  // ------>Sortida
  //
  System.out.println(
  " Digues a quina hora i minut surtes del estacionament (Primer la hora, desprès els minuts) "
  );
  Scanner entrada4 = new Scanner (System.in);
  int horaout = entrada4.nextInt();
  Scanner entrada5 = new Scanner (System.in);
  int minutout = entrada5.nextInt();
  // -------->Temps estacionament
  //
//Cal emmagatzemar la relació entre hores i minuts en una constant entera.
  int hora = horaout*60 - horaint*60;
  int horaprint = horaout - horaint;
  int minut = minutout - minutint;
  int tempsall = hora + minut;
  //int minutprint = tempsall-(horaprint*60);
  System.out.println(
  " Has estat aparca " + horaprint + " hora i " + minut + " minuts"
  ) ;
  // ------->lindar bonificació
  //
//Cal emmagatzemar en una variable entera el número total de minuts que el cotxe ha estat estacionat.
  boolean bono1 = tempsall <= 2;
  boolean bono2 = tempsall > 2;
  System.out.println(
  " Es menor o igual a 2 " + bono1
  );
   System.out.println(
  " Es major a 2 " + bono2
  );
  //-------->Cost
  //
//Cal emmagatzemar el cost d'estacionament per minut en cèntims i en una variable de tipus enter.
  int cost = tempsall * 2;
//Cal emmagatzemar el llindar de bonificació en hores i en una variable de tipus enter.
  int costbono = cost - 4;
  System.out.println(
  " El cost amb bonificació " + (double)costbono/100
  );
   System.out.println(
  " El cost sense bonificació " + (double)cost/100
  );
  System.out.println(
  " La teva matricula es  " + matricula
  );

  }
}
